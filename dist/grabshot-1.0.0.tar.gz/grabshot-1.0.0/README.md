# GrabShot - Website Screenshot API

Capture website screenshots with a simple Python API. **Free tier: 25 screenshots/month.**

```python
from grabshot import GrabShot

client = GrabShot("your-api-key")
screenshot = client.capture("https://github.com")
screenshot.save("github.png")
```

## Install

```bash
pip install grabshot
```

## Get Your API Key

1. Go to [grabshot.dev](https://grabshot.dev)
2. Sign up (free, no credit card)
3. Copy your API key from the dashboard

## Features

- **Screenshot any URL** as PNG, JPEG, or WebP
- **Full-page capture** for long pages
- **Dark mode** rendering
- **Block ads** and cookie banners
- **Retina (2x)** resolution
- **CSS selector** capture (screenshot specific elements)
- **HTML to image** rendering
- **AI cleanup** of popups/overlays (paid plans)
- **PDF generation** via [pdf.grabshot.dev](https://pdf.grabshot.dev)
- **Metadata extraction** via [metapeek.grabshot.dev](https://metapeek.grabshot.dev)

## Quick Examples

### Basic Screenshot

```python
from grabshot import GrabShot

client = GrabShot("gs_your_api_key")

# Simple screenshot
result = client.capture("https://example.com")
result.save("example.png")

# Full page, dark mode, no ads
result = client.capture(
    "https://news.ycombinator.com",
    full_page=True,
    dark_mode=True,
    block_ads=True,
    width=1440,
)
result.save("hackernews.png")
```

### Capture Specific Element

```python
# Screenshot just the hero section
result = client.capture(
    "https://stripe.com",
    selector=".hero-section",
    retina=True,
)
result.save("stripe-hero.png")
```

### HTML to Image

```python
# Render HTML directly (great for OG images)
html = """
<div style="width:1200px;height:630px;background:linear-gradient(135deg,#667eea,#764ba2);
            display:flex;align-items:center;justify-content:center;color:white;
            font-family:system-ui;font-size:48px;font-weight:bold;">
    My Blog Post Title
</div>
"""
result = client.html_to_image(html)
result.save("og-image.png")
```

### Generate PDF

```python
result = client.pdf("https://example.com", format="A4", landscape=True)
result.save("page.pdf")
```

### Extract Metadata

```python
meta = client.meta("https://github.com")
print(meta["title"])        # GitHub
print(meta["description"])  # Build and ship software...
print(meta["og:image"])     # https://github.githubassets.com/...
```

## Error Handling

```python
from grabshot import GrabShot, GrabShotError

client = GrabShot("gs_your_api_key")

try:
    result = client.capture("https://example.com")
    result.save("screenshot.png")
except GrabShotError as e:
    print(f"Error {e.status_code}: {e.message}")
```

## Plans

| Plan | Price | Screenshots/mo | Features |
|------|-------|----------------|----------|
| Free | $0 | 25 | Basic capture |
| Starter | $9/mo | 1,000 | + Ad blocking, dark mode |
| Pro | $29/mo | 10,000 | + AI cleanup, retina, priority |
| Business | $79/mo | 50,000 | + Custom branding, SLA |

[See full pricing](https://grabshot.dev/#pricing)

## Links

- [Website](https://grabshot.dev)
- [API Docs](https://grabshot.dev/docs.html)
- [API Explorer](https://grabshot.dev/api-explorer.html)
- [Dashboard](https://grabshot.dev/dashboard.html)
- [GitHub](https://github.com/aitaskorchestra/grabshot-python)

## License

MIT
